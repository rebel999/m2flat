package com.capgemini.hotelbooking.presentation;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.hotelbooking.bean.OwnerBean;
import com.capgemini.hotelbooking.dao.FlatDaoImpl;
import com.capgemini.hotelbooking.dao.IFlatDao;
import com.capgemini.hotelbooking.service.FlatServiceImpl;
import com.capgemini.hotelbooking.service.IFlatService;

public class Client {

	private static IFlatDao flatDao=new FlatDaoImpl();
	private static IFlatService flatService=new FlatServiceImpl();
	
	private static Scanner scanner=new Scanner(System.in);
	
	public static void main(String[] args) {
		
		while(true) {
			System.out.println();
			System.out.println();
			System.out.println("******Flat Registration System******");
			System.out.println("1.register flat");
			System.out.println("2.Exit");
			
			int choice=scanner.nextInt();
			
			switch(choice) {
			case 1:
				ArrayList<Integer> ownerList=flatService.getAllOwnerIds();
				System.out.println("Enter owner Id from given List : " + ownerList);
				 int ownerId=scanner.nextInt();
				
					List<OwnerBean> ownerDetails= new ArrayList<>();
					
					if(flatService.isValidOwnerId(ownerId))
					{
					ownerDetails=flatService.getOwnerDetails(ownerId);
						
					}else{
						System.out.println("enter existing owner id ");
					}
				
				
				
			}
		}

	}

}
