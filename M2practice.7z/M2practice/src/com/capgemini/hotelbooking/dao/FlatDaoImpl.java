package com.capgemini.hotelbooking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelbooking.bean.OwnerBean;
import com.capgemini.hotelbooking.util.DBConnection;

public class FlatDaoImpl implements IFlatDao {

	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		String sql="select owner_id from flat_owners";
		int ownerCount=0;
		try(
				Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
			) {
			ResultSet resultSet=statement.executeQuery(sql);
		ArrayList<Integer> owners=new ArrayList<>();
			int i=0;
			while(resultSet.next()) {
				
				owners.add(resultSet.getInt("owner_id"));
				ownerCount++;
				/*
				OwnerBean owner=new OwnerBean();
				owner.setOwnerId(resultSet.getInt("owner_id"));
				ownerIdList.add(owner);*/
			}
			if(ownerCount!=0){
				return owners;
			}else {
				return null;
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
	
		return null;
	}

	@Override
	public boolean isValidOwnerId(int ownerId) {
		
		String sql="select * from flat_owners where owner_id=?";
		
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement pst=connection.prepareStatement(sql);
			) {
			
			pst.setInt(1, ownerId);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()) {
				return true;
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<OwnerBean> getOwnerDetails(int ownerId) {
		List<OwnerBean> ownerDetails=new ArrayList<>();
String sql="select * from flat_owners where owner_id=?";
		
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement pst=connection.prepareStatement(sql);
			) {
			
			pst.setInt(1, ownerId);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()) {
				OwnerBean owner=new OwnerBean();
				owner=populateowners(owner,rs);
				ownerDetails.add(owner);
			}
			if(ownerDetails.equals(null))
			{
				System.out.println("dfsfsd");
				return null;}
			else
				return ownerDetails;
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}

	private OwnerBean populateowners(OwnerBean owner, ResultSet rs) throws SQLException {
		
		owner.setOwnerId(rs.getInt("owner_id"));
		owner.setOwnerName(rs.getString("owner_name"));
		owner.setMobile(rs.getString("mobile"));
		return owner;
		
	}

}
