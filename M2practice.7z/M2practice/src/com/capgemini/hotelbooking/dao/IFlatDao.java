package com.capgemini.hotelbooking.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelbooking.bean.OwnerBean;

public interface IFlatDao {

	public ArrayList<Integer> getAllOwnerIds();

	public boolean isValidOwnerId(int ownerId);

	public List<OwnerBean> getOwnerDetails(int ownerId);

}
