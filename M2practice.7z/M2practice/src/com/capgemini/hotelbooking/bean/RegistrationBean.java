package com.capgemini.hotelbooking.bean;

public class RegistrationBean {
	
	private Integer regNo;
	private Integer ownerId;
	private Integer flatType;
	private Integer flatArea;
	private Double rentAmount;
	private Double depositAmount;
	
	public RegistrationBean() {
		super();
	}

	public RegistrationBean(Integer regNo, Integer ownerId, Integer flatType,
			Integer flatArea, Double rentAmount, Double depositAmount) {
		super();
		this.regNo = regNo;
		this.ownerId = ownerId;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
	}

	public Integer getRegNo() {
		return regNo;
	}

	public void setRegNo(Integer regNo) {
		this.regNo = regNo;
	}

	public Integer getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Integer ownerId) {
		this.ownerId = ownerId;
	}

	public Integer getFlatType() {
		return flatType;
	}

	public void setFlatType(Integer flatType) {
		this.flatType = flatType;
	}

	public Integer getFlatArea() {
		return flatArea;
	}

	public void setFlatArea(Integer flatArea) {
		this.flatArea = flatArea;
	}

	public Double getRentAmount() {
		return rentAmount;
	}

	public void setRentAmount(Double rentAmount) {
		this.rentAmount = rentAmount;
	}

	public Double getDepositAmount() {
		return depositAmount;
	}

	public void setDepositAmount(Double depositAmount) {
		this.depositAmount = depositAmount;
	}

	@Override
	public String toString() {
		return "RegistrationBean [regNo=" + regNo + ", ownerId=" + ownerId
				+ ", flatType=" + flatType + ", flatArea=" + flatArea
				+ ", rentAmount=" + rentAmount + ", depositAmount="
				+ depositAmount + "]";
	}
	

	
}
