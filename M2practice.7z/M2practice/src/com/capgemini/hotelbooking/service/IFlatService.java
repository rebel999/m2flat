package com.capgemini.hotelbooking.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelbooking.bean.OwnerBean;

public interface IFlatService {

	public ArrayList<Integer>  getAllOwnerIds();

	
	public boolean isValidOwnerId(int ownerId);


	public List<OwnerBean> getOwnerDetails(int ownerId);

	

}
