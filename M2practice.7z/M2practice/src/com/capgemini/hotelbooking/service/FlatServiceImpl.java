package com.capgemini.hotelbooking.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelbooking.bean.OwnerBean;
import com.capgemini.hotelbooking.dao.FlatDaoImpl;
import com.capgemini.hotelbooking.dao.IFlatDao;



public class FlatServiceImpl implements IFlatService{

	private IFlatDao flatDao=new FlatDaoImpl();
	
	
	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		
		return flatDao.getAllOwnerIds();
	}

	@Override
	public boolean isValidOwnerId(int ownerId) {
		
		return flatDao.isValidOwnerId(ownerId);
	}

	@Override
	public List<OwnerBean> getOwnerDetails(int ownerId) {
		
		return flatDao.getOwnerDetails(ownerId);
	}

}
