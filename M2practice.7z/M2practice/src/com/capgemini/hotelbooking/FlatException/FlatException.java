package com.capgemini.hotelbooking.FlatException;

public class FlatException extends Exception{
	
private String message;
	
	
	
	public FlatException() {
		super();
	}

	public FlatException(String message) {
		super();
		this.message=message;
	}

	@Override
	public String toString() {
		return "FlatException [message=" + message + "]";
	}

	public String getMessage() {
		return message;
	}

}
